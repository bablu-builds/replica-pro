    """Task planner that turns a user request into validated parallel tasks."""
    import json
    from typing import Any

    from ..llm.base import LLMProvider
    from ..domain.types import TaskPlan, PlannedTask
    from ..domain.errors import PlanError, LLMError
    from ..logging.redaction import get_logger
    from .prompts import PLANNER_SYSTEM_PROMPT, build_planner_prompt
    from .validator import PlanValidator

    logger = get_logger("rmao.planner")


    class TaskPlanner:
        """Plan tasks from a user project request."""

        MIN_TASKS = 1
        MAX_TASKS = 16
        DEFAULT_TASKS = 4

        def __init__(self, llm: LLMProvider, validator: PlanValidator | None = None):
            self.llm = llm
            self.validator = validator or PlanValidator()

        async def plan(self, user_request: str, num_tasks: int | None = None) -> TaskPlan:
            """Generate a validated task plan from a user request."""
            num = self._clamp_num_tasks(num_tasks or self.DEFAULT_TASKS)
            prompt = build_planner_prompt(user_request, num)

            logger.info("planning_started", user_request=user_request[:100], num_tasks=num)

            try:
                response = await self.llm.generate_structured(
                    prompt=prompt,
                    system_prompt=PLANNER_SYSTEM_PROMPT,
                )
            except LLMError as e:
                logger.error("llm_planning_failed", error=str(e))
                raise PlanError(f"LLM planning failed: {e}") from e

            plan = self._parse_response(response.data)
            plan = self.validator.validate(plan)

            logger.info("planning_completed", task_count=len(plan.tasks), summary=plan.summary)
            return plan

        def _parse_response(self, data: dict[str, Any]) -> TaskPlan:
            if not isinstance(data, dict):
                raise PlanError("Planner response is not a JSON object")

            raw_tasks = data.get("tasks")
            if not isinstance(raw_tasks, list):
                raise PlanError("Planner response missing 'tasks' array")

            tasks: list[PlannedTask] = []
            for i, rt in enumerate(raw_tasks):
                if not isinstance(rt, dict):
                    raise PlanError(f"Task {i} is not an object")
                try:
                    tasks.append(PlannedTask(**rt))
                except Exception as e:
                    raise PlanError(f"Task {i} validation failed: {e}") from e

            return TaskPlan(tasks=tasks, summary=data.get("summary", ""))

        def _clamp_num_tasks(self, n: int) -> int:
            if n < self.MIN_TASKS:
                return self.MIN_TASKS
            if n > self.MAX_TASKS:
                return self.MAX_TASKS
            return n

        def summarize(self, plan: TaskPlan) -> str:
            """Return a read-only summary for CLI/API display."""
            lines = [f"Plan: {plan.summary}", f"Tasks ({len(plan.tasks)}):"]
            for t in plan.tasks:
                deps = f" (depends: {', '.join(t.dependencies)})" if t.dependencies else ""
                lines.append(f"  - {t.task_id}: {t.name}{deps}")
            return "
".join(lines)
