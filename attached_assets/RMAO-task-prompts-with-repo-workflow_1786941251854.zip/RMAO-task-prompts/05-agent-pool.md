# Task 5 — Agent Pool, Worker Allocation, and Lifecycle

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation. Read the existing domain types, planner, and execution provider before editing.

## Goal

Implement a reliable pool that assigns planned tasks to available workers/accounts, prevents double allocation, and always releases resources after success, failure, cancellation, or timeout.

## Required work

1. Define worker records with:
   - stable id;
   - capability labels;
   - provider reference;
   - current status;
   - current task/run id;
   - timestamps;
   - sanitized last error.
2. Implement allocation policies:
   - idle worker selection;
   - capability matching;
   - bounded concurrency;
   - no double checkout;
   - optional round-robin/load balancing.
3. Implement lifecycle methods:
   - register;
   - acquire;
   - heartbeat/health check;
   - release;
   - mark failed;
   - shutdown.
4. Use async-safe locking or an equivalent mechanism.
5. Handle cancellation and exceptions with guaranteed cleanup.
6. Ensure an unavailable worker does not cause infinite waiting. Return a typed capacity error or wait only up to a configured deadline.
7. Expose a sanitized status snapshot for the CLI/API.
8. Add tests for:
   - four workers handling four tasks;
   - a fifth task waiting or failing according to configuration;
   - capability mismatch;
   - concurrent acquire race;
   - release after exception;
   - timeout and cancellation;
   - worker health failure.

## Security and privacy

- Do not expose session credentials in worker status.
- Do not use email addresses or secret identifiers as public worker ids.
- Keep error messages safe for UI and logs.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- Resource ownership is correct under concurrency.
- No worker remains stuck as busy after a failed task.
- Pool behavior is deterministic in tests.
- Tests pass.

At the end, report the allocation policy, cleanup guarantees, and test results.
