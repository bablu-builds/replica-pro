# Task 9 — Security, Testing, Reliability, and Observability

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation. This task hardens the already-built system; do not replace working modules without a concrete reason.

## Goal

Make the orchestrator safe to operate, diagnosable under failure, and testable without real credentials or third-party side effects.

## Required work

1. Audit all secret handling:
   - environment variables/secrets;
   - LLM keys;
   - GitHub credentials;
   - Replit/provider credentials;
   - generated files and temporary directories.
2. Add centralized redaction for:
   - common token patterns;
   - authorization headers;
   - cookies/session values;
   - known configured secret values.
3. Add input and output size limits.
4. Add SSRF/path traversal/command injection protections relevant to the implementation.
5. Add timeouts and bounded retries to all network and worker operations.
6. Add safe cleanup for temporary repositories and worker resources.
7. Add structured logs and metrics/counters for:
   - runs;
   - tasks;
   - retries;
   - provider failures;
   - merge outcomes;
   - duration.
8. Add a test matrix using only fakes/mocks:
   - happy path;
   - malformed planner output;
   - malformed generated file map;
   - provider outage;
   - worker exhaustion;
   - GitHub rate limit;
   - merge conflict;
   - cancellation;
   - process restart/retry behavior.
9. Run the repository’s type checks, linters, formatters, and tests.
10. Document any remaining risk and the exact safe deployment configuration.

## Hard rules

- Do not use real tokens in tests.
- Do not call real Replit, GitHub, or LLM APIs in the test suite.
- Do not weaken validation merely to make a test pass.
- Do not log full user prompts if they may contain private project information.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- Tests are deterministic and do not require credentials.
- Security-sensitive values are redacted.
- Failure modes are observable.
- The project’s standard checks pass.

At the end, report checks run, findings fixed, and unresolved risks.
