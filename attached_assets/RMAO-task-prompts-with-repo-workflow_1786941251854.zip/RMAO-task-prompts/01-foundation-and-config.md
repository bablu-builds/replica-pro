# Task 1 — Foundation, Configuration, and Project Structure

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

You are implementing the foundation of a Replit Multi-Agent Orchestrator in the current Replit project.

Read the uploaded source document at:

`attached_assets/Replit-Multi-Agent-Orchestrator_1786929905753.md`

Before editing, inspect the existing repository and preserve unrelated applications, libraries, workflows, and user code. Create a clearly isolated module or app for this orchestrator instead of overwriting the existing project.

## Goal

Create the maintainable foundation for an orchestrator that:

- receives a project idea;
- decomposes it into parallel implementation tasks;
- assigns tasks to worker accounts/providers;
- executes workers concurrently;
- publishes worker changes to GitHub branches/PRs;
- reports progress and failures clearly.

Use the repository’s existing language and conventions where practical. If a new Python service is the best fit because the source document is Python-oriented, isolate it cleanly and document how it runs. Do not introduce a second competing app entry point without explaining why.

## Required work

1. Add the package/module structure for configuration, orchestration, providers, prompts, CLI/API entry points, and tests.
2. Add typed configuration loading with:
   - provider selection;
   - model and timeout settings;
   - worker/account configuration;
   - GitHub configuration;
   - concurrency and retry limits;
   - safe development/mock mode.
3. Validate required configuration at startup with actionable errors.
4. Add a safe `.env.example` containing names only, never real credentials.
5. Add or update `.gitignore` so secrets, caches, virtual environments, temporary repositories, and generated artifacts are excluded.
6. Add structured logging with redaction for credentials and authorization headers.
7. Define shared domain types/error types for:
   - planned task;
   - task status;
   - worker/account status;
   - execution result;
   - merge result;
   - orchestrator run summary.
8. Add minimal unit tests for configuration validation and secret redaction.
9. Add a README section that explains local setup, safe mock mode, and the order of the remaining tasks.

## Security constraints

- Never use, print, commit, or ask the user to paste raw Replit browser cookies in source files.
- Never hardcode API keys, GitHub tokens, session cookies, or passwords.
- Read secrets only through the project’s approved secret/integration mechanism.
- Do not claim that an external provider is connected if it is not.
- Fail explicitly when a required provider is unavailable.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- The project has one documented way to start the orchestrator.
- Configuration failures are detected before work starts.
- Logs cannot reveal known secret values.
- Tests pass.
- No unrelated existing artifact is broken.

At the end, report changed files, commands run, test results, and any provider APIs that still need a later adapter.
