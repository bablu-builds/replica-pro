# Replit Multi-Agent Orchestrator — Task Prompts

यह folder `attached_assets/Replit-Multi-Agent-Orchestrator_1786929905753.md` में दिए गए काम को छोटे, क्रमबद्ध implementation tasks में बाँटता है।

## Repository (workspace + backup)

सारा काम इस GitHub repo में होगा, ये hi central workspace aur backup hai:

`https://github.com/bablu-builds/replica-pro`

हर task (`01-...` से `10-...` तक) में अब ek "Repository workflow" section hai jo Replit Agent ko force karta hai:

1. Pehle repo se **latest code pull** karo.
2. Us latest code par **naya implementation** karo (jo us task mein likha hai).
3. Kaam poora hone ke baad **commit + push** karo wapas usi repo mein.

Isse code kabhi bhi sirf local Replit session mein nahi rehta — hamesha `replica-pro` repo mein backup/version ho jaata hai, aur agla task hamesha pichle task ke latest pushed code par shuru hota hai.

## इस्तेमाल करने का तरीका

1. Replit Agent ko sabse pehle bata do ki project repo `https://github.com/bablu-builds/replica-pro` hai aur usi se pull/push karna hai (agar Agent khud clone/connect nahi kar sakta to pehle manually connect/clone kara do).
2. Prompts को नीचे दिए गए क्रम में एक-एक करके Replit Agent को दें।
3. अगला prompt तभी दें जब पिछले task की implementation, verification, **aur repo push** पूरी हो जाए।
4. हर task के बाद Agent से changed files, tests, commit/push confirmation, और known limitations का छोटा summary लें।
5. `10-final-integration.md` सबसे अंत में चलाएँ।

## Prompt order

1. `01-foundation-and-config.md` — project structure, configuration, logging, error model
2. `02-llm-manager.md` — provider-neutral LLM layer
3. `03-task-planner.md` — user goal को validated parallel tasks में बदलना
4. `04-replit-execution-adapter.md` — Replit execution provider abstraction
5. `05-agent-pool.md` — account/worker lifecycle and load balancing
6. `06-parallel-executor.md` — parallel orchestration and progress tracking
7. `07-github-merger.md` — repository, branches, PRs, and conflict workflow
8. `08-cli-and-api-entrypoints.md` — user-facing CLI/API entry points
9. `09-security-testing-and-observability.md` — security, tests, retries, and logs
10. `10-final-integration.md` — end-to-end wiring, docs, and acceptance verification

## Important safety corrections

- Original document में Replit `connect.sid` cookies को `.env` में रखने का सुझाव है। Production implementation में raw browser cookies को log, commit, UI, prompt, या source file में नहीं रखना है।
- Credentials केवल Replit Secrets / approved integrations से पढ़े जाएँ। Unsupported private GraphQL mutations या browser-cookie automation को default implementation न बनाया जाए।
- अगर official Replit execution API उपलब्ध नहीं है, तो स्पष्ट `MockExecutionProvider` और pluggable interface बनायें; fake success या silent fallback न दें।
- GitHub token, LLM key, session credential, और generated project secrets कभी output, logs, PR body, exception message, या prompt payload में expose न हों — ye rule `replica-pro` repo mein push karte waqt bhi lagu hota hai (secrets kabhi commit na hon).
- Original source का आख़िरी हिस्सा `github_merger.py` के बीच में कट गया है। Missing behavior को acceptance criteria और tests से पूरा करें, source की incomplete tail को blindly copy न करें।

## Source

यह task split उसी uploaded file से बनाया गया है:

`attached_assets/Replit-Multi-Agent-Orchestrator_1786929905753.md`
