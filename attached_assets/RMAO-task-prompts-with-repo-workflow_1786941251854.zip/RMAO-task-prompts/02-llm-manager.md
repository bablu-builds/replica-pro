# Task 2 — Provider-Neutral LLM Manager

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation from the previous task. Read the uploaded source document and inspect the foundation that already exists. Do not rewrite unrelated code.

## Goal

Implement a single LLM manager interface that can route planning, code-generation, and merge-resolution requests to configured providers while keeping the rest of the orchestrator provider-neutral.

The source document names OpenAI, DeepSeek, Kimi/Moonshot, and GLM/Zhipu. Support those providers only through a common adapter interface. Prefer an official SDK or an OpenAI-compatible client where the provider documents that compatibility.

## Required work

1. Define an interface/protocol for:
   - structured JSON generation;
   - plain text generation;
   - model/provider metadata;
   - timeout and cancellation.
2. Implement a provider factory driven by configuration.
3. Validate provider-specific configuration before making a request.
4. Make structured output robust:
   - request JSON mode when supported;
   - parse and validate the response;
   - reject malformed JSON with a useful typed error;
   - never silently return an empty or fabricated result.
5. Add request timeouts, bounded retries, and retry classification.
6. Ensure prompts never include credentials or unnecessary private repository data.
7. Add a deterministic fake LLM adapter for tests and local mock mode.
8. Add tests for:
   - provider selection;
   - unsupported provider;
   - missing provider secret;
   - valid structured output;
   - malformed output;
   - timeout/retry behavior;
   - secret redaction.
9. Keep provider names, model names, base URLs, and feature support configurable rather than scattered through business logic.

## Important constraints

- Do not ask the user for an API key if a Replit-managed AI integration is already available and appropriate.
- Never log prompts or responses that contain secrets.
- Do not use a fake success response in production mode.
- Do not instantiate or cache an expiring authenticated client in a way that prevents credential refresh.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- Task planner and merge resolver can depend only on the common LLM interface.
- Mock mode works without any external API.
- Real provider failures are visible and actionable.
- Tests pass and no secret values appear in logs.

At the end, report changed files, supported providers, test results, and any provider-specific limitation.
