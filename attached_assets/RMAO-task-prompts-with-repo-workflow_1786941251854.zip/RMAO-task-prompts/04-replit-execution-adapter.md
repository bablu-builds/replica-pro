# Task 4 — Replit Execution Provider Abstraction

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation using the uploaded source as product context. Inspect the current code before editing.

## Goal

Implement the provider boundary used to create or access a worker environment, write generated files, run commands, and collect results. The orchestrator must not depend directly on private Replit GraphQL details.

## Required work

1. Define an `ExecutionProvider` interface with operations for:
   - creating or selecting a worker environment;
   - writing a file safely;
   - running a command with timeout;
   - reading execution output/status;
   - cleaning up or releasing a worker;
   - health checking.
2. Define typed request/result/error models.
3. Implement `MockExecutionProvider` for local development and tests:
   - deterministic;
   - no network;
   - explicit simulated failures;
   - never reports success when a configured operation failed.
4. Implement the real Replit adapter only using documented/approved APIs or integrations available to this project.
5. If the required Replit API is not available, leave a clear `NotConfiguredExecutionProvider` that fails explicitly and document the missing capability. Do not automate browser sessions or scrape private GraphQL mutations.
6. Enforce safe file paths:
   - reject absolute paths;
   - reject `..` traversal;
   - reject writes outside the worker root;
   - enforce size limits.
7. Enforce command policies:
   - timeout;
   - output limit;
   - cancellation;
   - no secret interpolation into logs;
   - no unrestricted destructive command by default.
8. Add tests for path safety, command timeout, output truncation, mock success, mock failure, and unavailable real provider.

## Credential rules

- Never place raw `connect.sid` values in `.env.example`, prompts, logs, test fixtures, or source control.
- Never print authorization headers or secret environment variables.
- Use Replit Secrets or an approved connector when available.
- Keep credential acquisition isolated inside the provider adapter.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- The planner/executor can run entirely with the mock provider.
- Production mode fails clearly if the real provider is not configured.
- Provider-specific code is isolated behind the interface.
- Tests pass.

At the end, report which provider path is implemented, which is mock-only, and how a future approved provider can be added.
