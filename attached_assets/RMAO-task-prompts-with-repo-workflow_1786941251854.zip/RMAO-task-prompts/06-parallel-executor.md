# Task 6 — Parallel Executor and Run State

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation using the typed planner, LLM manager, execution provider, and agent pool.

## Goal

Build the core orchestration engine that executes independent planned tasks concurrently, tracks every run, and returns a complete result without hiding partial failures.

## Required work

1. Define an orchestrator run state machine:
   - created;
   - planning;
   - planned;
   - executing;
   - partially_failed;
   - execution_failed;
   - ready_for_merge;
   - merged;
   - cancelled;
   - completed_with_warnings.
2. Execute tasks concurrently up to the configured limit.
3. For each task:
   - acquire a worker;
   - create/select its environment;
   - ask the LLM for a structured file map;
   - validate file paths and content limits;
   - write files;
   - run the configured verification command;
   - collect logs/status;
   - release the worker in a `finally`-equivalent cleanup path.
4. Make task retries bounded and idempotency-aware.
5. Persist or expose sanitized progress events:
   - run started;
   - task queued;
   - task started;
   - file generation completed;
   - verification completed;
   - task failed;
   - task completed;
   - run completed.
6. Support cancellation and deadlines.
7. Prevent one task failure from hiding the results of other tasks.
8. Add a safe artifact contract for generated files:
   - normalized paths;
   - content;
   - checksums;
   - task ownership;
   - verification result.
9. Add tests for full success, one-task failure, all-task failure, cancellation, timeout, retry exhaustion, and worker cleanup.

## LLM output rules

- Generated code must be parsed as a validated file map, never executed directly from an untrusted string.
- Reject malformed JSON and unsafe files.
- Do not include secrets in generated prompts or returned artifacts.
- Do not pretend a verification command passed if it did not run or failed.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- Four independent tasks can run concurrently in mock mode.
- Partial failures are visible and actionable.
- Every worker is released on every exit path.
- The run summary is suitable for API/CLI display.
- Tests pass.

At the end, report the state machine, event model, cleanup behavior, and test results.
