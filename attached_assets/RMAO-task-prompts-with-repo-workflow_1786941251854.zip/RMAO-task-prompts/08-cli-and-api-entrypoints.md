# Task 8 — User-Facing CLI and API Entry Points

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation after the core orchestration and GitHub layers are available.

## Goal

Provide a simple, usable interface for starting an orchestrator run, inspecting its plan/progress, cancelling it, and retrieving the final result.

## Required work

1. Add a CLI command that accepts:
   - project request;
   - optional task count;
   - mock mode;
   - provider/model selection;
   - concurrency and timeout overrides;
   - dry-run planning mode.
2. Add a small HTTP API only if the current project already has an API service or if the architecture requires one. Do not create duplicate servers/workflows.
3. Expose endpoints/commands for:
   - health/config readiness;
   - create run;
   - get run status;
   - get plan;
   - get task results;
   - cancel run;
   - get final repository/PR results.
4. Validate all input at the boundary.
5. Return consistent error responses without stack traces or secrets.
6. Add request/run correlation ids.
7. Stream or poll sanitized progress events.
8. Ensure long-running work is not accidentally tied to a request that can time out.
9. Add examples for a mock-mode run.
10. Add tests for input validation, dry run, successful mock run, cancellation, not-found run, and provider-not-ready errors.

## UX requirements

- Make the first-run experience clear for a non-expert.
- Explain whether the app is in mock mode, dry-run mode, or real execution mode.
- Show partial failures instead of a generic “something went wrong”.
- Never display or echo credential values.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- A user can run the complete flow locally in mock mode.
- Status and errors are understandable.
- Existing app routes/workflows remain intact.
- Tests pass.

At the end, report the exact commands/endpoints and a mock-mode example.
