# Task 7 — GitHub Repository, Branches, Pull Requests, and Merge Flow

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation. Read the current executor result models and existing repository conventions before editing.

## Goal

Implement the GitHub publishing layer that takes validated task artifacts, creates a repository/branches when configured, pushes task changes, opens pull requests, and merges them safely.

## Required work

1. Define a provider-neutral Git hosting interface for:
   - repository creation or selection;
   - branch creation;
   - file commit/push;
   - pull request creation;
   - mergeability/status refresh;
   - merge;
   - close/delete cleanup where explicitly configured.
2. Implement a GitHub adapter using an approved GitHub integration or documented SDK.
3. Implement a fake adapter for tests.
4. Generate safe, deterministic repository and branch names:
   - normalize user/task names;
   - limit length;
   - avoid path/control characters;
   - avoid collisions.
5. Ensure task branches have clear ownership and do not overwrite unrelated files.
6. Open PRs with sanitized metadata and useful acceptance information.
7. Merge in a deterministic order or explicit dependency order.
8. Detect conflicts and return a typed conflict result.
9. If LLM conflict resolution is enabled:
   - send only the minimum required diff/context;
   - validate the returned content;
   - run tests before pushing the resolution;
   - never auto-merge an unresolved or unverified result.
10. Add tests for repository creation, branch naming, push failure, PR creation, non-mergeable PR, merge success, conflict handling, and idempotent reruns.

## Security rules

- Never put GitHub tokens in clone URLs, logs, PR bodies, error messages, or generated files.
- Prefer credential-aware clients that refresh safely.
- Treat generated code and task metadata as untrusted input.
- Default repositories to private unless the user explicitly configures public visibility.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- Mock mode can simulate the entire GitHub flow.
- Real mode fails clearly when GitHub is not connected/configured.
- No credential leakage occurs.
- A conflict cannot be silently marked as merged.
- Tests pass.

At the end, report the GitHub integration path, merge policy, conflict policy, and test results.
