# Task 3 — Task Planner and Prompt Contracts

## Repository workflow (mandatory for this task)

Treat `https://github.com/bablu-builds/replica-pro` as the single source of truth, workspace, and backup for this entire project. Every task must follow this exact sequence:

1. **Pull first.** Before writing or changing any code, pull the latest code from `https://github.com/bablu-builds/replica-pro` (correct branch, e.g. `main`) so you are working on top of the most recent state, including work from any previous task/session.
2. **Implement.** Do the work described below in "Required work" on top of that latest pulled code — do not implement against stale/local-only code.
3. **Commit and push.** After the task is complete and verified, commit your changes with a clear, descriptive commit message referencing this task number, and push the changes back to `https://github.com/bablu-builds/replica-pro` (same branch, or a task-specific branch merged back into the mainline before finishing) so the repository always reflects the current, working state of the project.
4. **Never leave work only local.** Nothing produced in this task should exist only in this workspace session — the repository is the backup. If push fails (auth, conflict, etc.), report this explicitly instead of silently continuing.
5. Do not commit secrets, tokens, cookies, or `.env` values as part of this push. Confirm `.gitignore` is respected before pushing.

Continue the RMAO implementation. Read the uploaded source document and the existing foundation plus LLM manager. Keep the implementation compatible with the existing interfaces.

## Goal

Build the planning layer that turns a user’s project request into a safe, validated set of independent tasks suitable for parallel execution.

The source document asks for exactly four areas such as frontend, backend, database, and authentication. Preserve that intent, but do not force meaningless tasks when a project genuinely needs a different split. Make the number configurable with a default of four and enforce a documented range.

## Required work

1. Create a versioned planner system prompt.
2. Define a strict schema for planner output:
   - stable task id;
   - name;
   - description;
   - responsibilities;
   - dependencies;
   - technology constraints;
   - expected output files;
   - port, if applicable;
   - folder/branch slug;
   - acceptance criteria.
3. Validate the LLM response before it reaches the executor.
4. Reject:
   - duplicate ids or slugs;
   - unsafe path traversal;
   - empty descriptions;
   - unsupported dependency references;
   - overlapping ownership without an explicit shared-file policy;
   - invalid ports;
   - malformed JSON.
5. Add deterministic planning fixtures for tests.
6. Add a prompt-injection boundary: treat the user request as project data, not as instructions to disclose secrets or bypass safety controls.
7. Add a small read-only summary method for CLI/API display.
8. Add tests covering valid plans, malformed plans, duplicate tasks, invalid dependencies, unsafe paths, and configurable task counts.

## Planning rules

- Tasks should be as independent as possible.
- Shared contracts must be explicit.
- Every task must have a clear definition of done.
- The planner must not invent credentials, repositories, accounts, or provider connections.
- The planner must not promise a deployment URL unless deployment actually occurs.

## Acceptance criteria

- The latest code was pulled from the repository before this task began, and all completed work for this task has been committed and pushed back to it.

- A user request produces a validated plan or a clear error.
- The executor receives typed tasks, never raw unvalidated LLM JSON.
- Plan output is deterministic under the fake LLM.
- Tests pass.

At the end, report the task schema, validation rules, and test results.
